import socket
import time
import select
import threading
import sqlite3
import BookList
import Adminstrator

IP = ''
PORT = 5722

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server_socket.bind((IP, PORT))

server_socket.listen(10)
print("server up!")

socket_list = [server_socket]

clients = {}

def check(tableName, username, passw):
    conn = sqlite3.connect("Library.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM {} WHERE ID = {} , NAME = {}".format(tableName , passw , username))
    s = cursor.fetchall()

    if not len(s):
        return False

    return True  

def captcha():
    pass


def adminLogin(client_socket):

    while True:
        client_socket.send(bytes("1:Add Member , 2:Add Book, 3:Add Admin, 4:GetInformation of book, 5:Tamdid Zaman 6:Remove Book , 7:Rent Book , 8:Who Have Book", 'utf-8'))
        msg = client_socket.recv(1024).decode("utf-8")

        if msg == '1':
            client_socket.send(bytes("Name, Age", 'utf-8'))
            msg = client_socket.recv(1024).decode("utf-8")
            info_l = msg.split(",")
            
            m = Member.Members(info_l[0] , int(info_l[1]))
            m.addMember()

        elif msg == '2':   
            client_socket.send(bytes("Name, Author , Category , International ,  BookId , Count", 'utf-8'))
            msg = client_socket.recv(1024).decode("utf-8")
            info_l = msg.split(",") 

            b = BookList.Book(info_l[0] , info_l[1] , info_l[2] , info_l[3] , info_l[4] , int(info_l[5]))
            b.addBook()

        elif msg == '3':

            client_socket.send(bytes("Name, Age", 'utf-8'))
            msg = client_socket.recv(1024).decode("utf-8")
            info_l = msg.split(",")
            
            m = Member.Members(info_l[0] , int(info_l[1]))
            m.addAdmin()

        elif msg == '4':

            client_socket.send(bytes("Enter Id of the book", 'utf-8'))
            msg = client_socket.recv(1024).decode("utf-8")

            a = Adminstrator.Admin()
            a.getInformetionAboutBook(msg)

        elif msg == '5':
            pass

        elif msg == '6':
            client_socket.send(bytes("Name, Author , Category , International ,  BookId , Count", 'utf-8'))
            msg = client_socket.recv(1024).decode("utf-8")
            info_l = msg.split(",") 

            b = BookList.Book(info_l[0] , info_l[1] , info_l[2] , info_l[3] , info_l[4] , int(info_l[5]))
            b.removeBook()

        elif msg == '7':
            pass

        else:
            pass

def memberLogin(client_socket):

    while True:
        client_socket.send(bytes("1:List of  borrowed book 2:Get Information of book" , 'utf-8'))
        msg = client_socket.recv(1024).decode("utf-8")

        if msg == '1':
            client_socket.send(bytes("Enter your Id", 'utf-8'))
            msg = client_socket.recv(1024).decode("utf-8")

            a = Adminstrator.Admin.getListOfBorrowedBook(msg)

        else:
            client_socket.send(bytes("Enter Id of the book", 'utf-8'))
            msg = client_socket.recv(1024).decode("utf-8")

            a = Adminstrator.Admin()
            a.getInformetionAboutBook(msg)
            


def askCircumstance(client_socket):

    flag = False
    cnt  = 0
    while not flag:
        client_socket.send(bytes("1 : Admin or 2 : Member", 'utf-8'))
        msg = client_socket.recv(1024).decode("utf-8")

        if msg == '1':
            while cnt < 3:
                if check("admins"):
                    adminLogin(client_socket)
                    flag = True
                    break
                else:
                    cnt += 1
            if cnt == 3:
                captcha(client_socket)         

            # t1 = threading.Thread(target = adminLogin , args = (client_socket,))
            # t1.start()
        
        else:
            while cnt < 3:
                if check("members"):
                    memberLogin(client_socket)
                    flag = True
                    break
                else:
                    cnt += 1
            if cnt == 3:
                captcha(client_socket)


while True:
    read_socket, write_socket, exception_socket = select.select(socket_list, [], socket_list)

    for s in read_socket:
        if s == server_socket:

            client_socket, address = server_socket.accept() 
            if client_socket:  

                client_socket.send(bytes("welcome!", 'utf-8'))
                
                print("Connection Established from {}".format(address))

                t = threading.Thread(target = askCircumstance, args = (client_socket,))
                t.start()

                socket_list.append(client_socket)
    
        else:
            try:
                message = s.recv(1024)
            except:
                # if not message:
                print("NOt message")
                try:
                    socket_list.remove(s)
                    del clients[s]
                except:
                    pass
                continue
            else:
                # client_socket = findReceiver(s)
                client_socket.send(message)
            
    for s in exception_socket:
        try:
            socket_list.remove(s)
            del clients[s]
        except:
            pass
    time.sleep(2)

conn.close()
server_socket.close()